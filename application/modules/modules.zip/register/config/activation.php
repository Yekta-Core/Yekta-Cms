<?php

$config['enable_email_activation'] = false;
$config['activation_sender_mail'] = "no-reply@yourserver.com";