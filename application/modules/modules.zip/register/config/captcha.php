<?php

$config['use_captcha'] = true;