<?php

$config['send_sms_enable'] = false;

$config['SoapClient'] = "http://www.sirafpayamak.ir/post/send.asmx?wsdl";

$config['username'] = "lianwow";
$config['password'] = "admin114";

$config['from'] = "30002577000770";

$config['isflash'] = false;

$config['udh'] = "";

$config['recId'] = array(0);

$config['status'] = 0x0;



